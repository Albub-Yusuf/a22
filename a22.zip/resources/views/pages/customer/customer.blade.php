@extends('layouts.dashboardMaster')

@section('content')

@include('components.customer.list')

@endsection