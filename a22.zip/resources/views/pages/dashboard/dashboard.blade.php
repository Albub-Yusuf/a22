@extends('layouts.dashboardMaster')
@section('content')

<!-- dashboard stats -->
@include('components.dashboard.stats')
<!--  -->



@endsection