@extends('layouts.dashboardMaster')

@section('content')

@include('components.campaign.list')

@endsection