@extends('layouts.master')

@section('content')

@include('components.shopOwner.registrationForm')

@endsection