<div class="card shadow-lg my-5 p-3 col-md-10">
    <div class="col-md-12">
        <div class="col-md-12">
            <div class="col-md-12 d-flex justify-content-between">
                <h3><?php echo e($title); ?></h3>
                <a class="btn btn-primary" href="<?php echo e(route('customer.create')); ?>">Add Customer</a>
            </div>
        </div>
        <br>

        <table class="table table-striped" id="customer_list">
            <thead>
                <th>Serial</th>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Action</th>
            </thead>
            <tbody id="tableList">
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($serial++); ?></td>
                        <td><?php echo e($customer->name); ?></td>
                        <td><?php echo e($customer->email); ?></td>
                        <td><?php echo e($customer->status); ?></td>
                        <td>
                           <div class="action-container d-flex" >
                           <div><a  href="<?php echo e(route('customer.edit',$customer->id)); ?>" class="btn btn-sm btn-warning">Edit</a></div>&nbsp;&nbsp; |  &nbsp;&nbsp;
                            <div>
                                <form action="<?php echo e(route('customerDelete',$customer->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </div>
                           </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<script>
 $(function() {
   $('#customer_list').DataTable();
 });
</script><?php /**PATH D:\a22\resources\views/components/customer/list.blade.php ENDPATH**/ ?>