

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('components.shopOwner.registrationForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\a22\resources\views/pages/shopOwner/registration.blade.php ENDPATH**/ ?>