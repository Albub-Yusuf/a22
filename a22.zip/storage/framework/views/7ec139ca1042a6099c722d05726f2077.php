<div class="row mb-5 py-3">
    <div class="col-md-10">
        <div class="container">

                 <div class="row">
                    <div class="col-md-4">
                        <div class="card shadow-lg">
						    <div   div class="card-body p-5">
							    <h1 class="fs-4 card-title fw-bold mb-4">Total Customer</h1>
                                <h3><?php echo e($totalCustomer); ?></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card shadow-lg">
						    <div   div class="card-body p-5">
							    <h1 class="fs-4 card-title fw-bold mb-4">Total Campaign</h1>
                                <h3><?php echo e($totalCampaign); ?></h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card shadow-lg">
						    <div   div class="card-body p-5">
							    <h1 class="fs-4 card-title fw-bold mb-4">Total Product</h1>
                                <h3>10</h3>
                            </div>
                        </div>
                    </div>
                 </div>
                    

        </div>
    </div>
</div><?php /**PATH D:\a22\resources\views/components/dashboard/stats.blade.php ENDPATH**/ ?>