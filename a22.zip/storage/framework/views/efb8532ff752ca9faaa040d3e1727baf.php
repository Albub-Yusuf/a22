<div class="card shadow-lg my-5 p-3 col-md-10">
    <div class="col-md-12">
        <div class="col-md-12">
            <div class="col-md-12 d-flex justify-content-between">
                <h3><?php echo e($title); ?></h3>
                <a class="btn btn-primary" href="<?php echo e(route('campaign.create')); ?>">Create Campaign</a>
            </div>
        </div>
        <br>

        <table class="table table-striped table-hover" id="campaign_list">
            <thead>
                <th>Serial</th>
                <th>Title</th>
                <th>Action</th>
            </thead>
            <tbody id="tableList">
                <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($serial++); ?></td>
                        <td><?php echo e($campaign->title); ?></td>
                        <td>
                           <div class="action-container d-flex" >
                           <div><a  href="<?php echo e(route('campaign.edit',$campaign->id)); ?>" class="btn btn-sm btn-warning"><strong>Edit</strong></a></div>&nbsp;&nbsp; |  &nbsp;&nbsp;
                            <div>
                                <form action="<?php echo e(route('campaignDelete',$campaign->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-danger"><strong>Delete</strong></button>
                                </form>
                            </div>&nbsp;&nbsp;&nbsp; | &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                            <div><a  href="<?php echo e(route('campaignMailData',$campaign->id)); ?>" class="btn btn-sm btn-success"><strong>Send Promotional Email</strong></a></div>&nbsp;&nbsp; &nbsp;&nbsp;

                           </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<script>
 $(function() {
   $('#campaign_list').DataTable();
 });
</script><?php /**PATH D:\a22\resources\views/components/campaign/list.blade.php ENDPATH**/ ?>