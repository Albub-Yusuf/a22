

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('components.campaign.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\a22\resources\views/pages/campaign/campaign.blade.php ENDPATH**/ ?>