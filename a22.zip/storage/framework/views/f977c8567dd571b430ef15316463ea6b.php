<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo e($title); ?></title>
        
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="<?php echo e(asset('assets/css/styles.css')); ?>" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/dtables.css')); ?>">
        <script src="<?php echo e(asset('assets/js/axios.min.js')); ?>"></script>

                <!-- Bootstrap core JS-->
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
                  <!-- Core theme JS-->
        <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/dtables.js')); ?>"></script>

    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light">Assignment 22</div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="<?php echo e(url('/customer')); ?>">Customers</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="<?php echo e(url('/campaign')); ?>">Campaigns</a>


                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="<?php echo e(url('/shop-owner-logout')); ?>">Logout</a>
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom" style="min-height: 58px; display:flex; justify-content:space-around;">
          
                    <div class="col-md-4">
                        <span><h4 style="margin-left:20px; padding:0 5px;"><?php echo e($title); ?></h4></span>
                    </div>
                
                    <div class="col-md-6">
                        <span class="text-center">Welcome - <?php echo e($shopOwnerName->firstName); ?>   <?php echo e($shopOwnerName->lastName); ?></span>
                    </div>

                    <div class="col-md-2">
                        <span> &nbsp;&nbsp;&nbsp;  <a href="<?php echo e(url('/shop-owner-logout')); ?>">Logout</a></span>
                    </div>

                </nav>
                <!-- Page content-->
                <div class="container-fluid">
                    
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>

      
    </body>
</html>
<?php /**PATH D:\a22\resources\views/layouts/dashboardMaster.blade.php ENDPATH**/ ?>