

<?php $__env->startSection('content'); ?>

<div class="card shadow-lg my-5 p-3 col-md-8">
    <div class="col-md-12">
        <div class="col-md-12">
            <div class="col-md-12">
                <h3><?php echo e($title); ?></h3>
             <div class="row">
                <div class="col-md-10">
                <form class="form-control" action="<?php echo e(route('send-campaign-email')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="campaignId" value="<?php echo e($campaignDetails->id); ?>">
                    <div class="mb-3">
                        <label for="status"><h5>Select Customer Group: </h5></label><br>
                        <select name="status" id="status" class="form-control">
                            <option value="subscribed">Subscribed</option>
                            <option value="unsubscribed">Unsubscribed</option>    
                            <option value="new">New</option>
                            <option value="all">All</option>  
                        </select>
                    </div>

                    <div class="mb-3">
                        <input class="btn btn-primary" type="submit" value="Send Mail to the customers">
                    </div>
                    
                </form>
                </div>
             </div>

            </div>
        </div>
    </div>
</div>
<br><br>
<div class="row my-5">
    <div class="col-md-6">

    <div class="card text-center">
  <div class="card-header">
    <h4><?php echo e($campaignDetails->title); ?></h4>
  </div>
  <div class="card-body">
    <h5 class="card-title">
        <p class="card-text"><?php echo e($campaignDetails->details); ?></p>
    </h5>
    <br><br><br><hr>
    <iframe src="<?php echo e($campaignDetails->url); ?>" height="500" width="700" title="Iframe Example"></iframe>
    
  </div>
  <div class="card-footer text-muted">
  <a href="<?php echo e($campaignDetails->url); ?>" target="_blank" class="btn btn-primary">Visit Link</a>
  </div>
</div>

    </div>
</div>
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\a22\resources\views/pages/campaign/campaignMailForm.blade.php ENDPATH**/ ?>