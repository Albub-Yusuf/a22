

<?php $__env->startSection('content'); ?>

<div class="card shadow-lg my-5 p-3 col-md-10">
    <div class="col-md-12">
        <div class="col-md-12">
            <div class="col-md-12">
                <h3><?php echo e($title); ?></h3>

             <div class="row">
                <div class="col-md-10">
                <form class="form-control" action="<?php echo e(route('customerUpdate',$customerDetails->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>

                    <div class="mb-3">
                        <label for="name" id="name"><h5>Customer Name: </h5></label>
                        <br>
                        <input class="form-control" type="text" id="name" name="name" placeholder="Enter customer name" value="<?php echo e($customerDetails->name); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" id="email"><h5>Customer Email: </h5></label>
                        <br>
                        <input class="form-control" type="email" id="email" name="email" value="<?php echo e($customerDetails->email); ?>" placeholder="Enter customer email" required>
                    </div>

                    <div class="mb-3">
                        <label for="Address" id="address"><h5>Customer Address: </h5></label>
                        <br>
                        <input class="form-control" type="text" id="address" name="address" value="<?php echo e($customerDetails->address); ?>" placeholder="Enter customer address" required>
                    </div>

                    <div class="mb-3">
                        <label for="phone" id="phone"><h5>Customer Contact Number: </h5></label>
                        <br>
                        <input class="form-control" type="text" id="phone" name="phone" value="<?php echo e($customerDetails->phone); ?>" placeholder="Enter customer phone" required>
                    </div>

                    <div class="mb-3">
                        <label for="status"><h5>Select Customer Status: </h5></label><br>
                        <select name="status" id="status" class="form-control">
                            <?php if($customerDetails->status == 'subscribed'): ?>
                                <option value="subscribed" selected>Subscribed</option>
                                <option value="unsubscribed">Unsubscribed</option>
                                <option value="new">New</option>   
                            <?php endif; ?>

                            <?php if($customerDetails->status == 'unsubscribed'): ?>
                                <option value="unsubscribed" selected>Unsubscribed</option>
                                <option value="subscribed">Subscribed</option>
                                <option value="new">New</option>   
                            <?php endif; ?>

                            <?php if($customerDetails->status == 'new'): ?>
                                 <option value="new" selected>New</option>   
                                <option value="unsubscribed">Unsubscribed</option>
                                <option value="subscribed">Subscribed</option>
                            <?php endif; ?>
                            
                              
                        </select>
                    </div>

                    <div class="mb-3">
                        <input class="btn btn-primary" type="submit" value="Create Customer">
                    </div>
                    



                </form>
                </div>
             </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\a22\resources\views/pages/customer/edit.blade.php ENDPATH**/ ?>