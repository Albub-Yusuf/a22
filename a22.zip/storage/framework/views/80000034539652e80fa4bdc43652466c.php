<div class="card shadow-lg my-5 p-3 col-md-10">
    <div class="col-md-12">
        <div class="col-md-12">
            <div class="col-md-12 d-flex justify-content-between">
                <h3><?php echo e($title); ?></h3>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\a22\resources\views/components/customer/create.blade.php ENDPATH**/ ?>